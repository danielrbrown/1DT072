#!/bin/bash

# Download and install NVM
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.0/install.sh | bash

# Set up NVM environment variables
export NVM_DIR="$HOME/.config/nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"  # This loads nvm
[ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"  # This loads nvm bash_completion

# Download and install Node.js
nvm install 22

# Verify the Node.js version
node -v # should print something like `v22.x.x`

# Verify the npm version
npm -v # should print something like `10.x.x`

# Download Juice Shop repository
git clone https://github.com/juice-shop/juice-shop.git --depth 1

# Navigate to the Juice Shop directory
cd juice-shop

# Install dependencies
npm --verbose install

# Start Juice Shop
npm start

